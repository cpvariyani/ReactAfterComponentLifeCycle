import React, { Component } from "react";

export default class Player extends Component {
  constructor(props) {
    super(props);
    console.log("Player Constructor.");
    this.state = {
      player: [{ id: "1", name: "Player ABC" }],
    };
  }

  static getDerivedStateFromProps(props, state) {
    console.log("Player getDerivedStateFromProps. " + props);
    return state;
  }

  componentDidMount() {
    console.log("Player componentDidMount.");
  }

  render() {
    console.log("Player render.");

    return <div>I am a player {this.state.player[0].name}</div>;
  }
}
