import React, { Component } from "react";

import "./Employee.css";

export default class Employee extends Component {

  render() {
    return (
      <div className="Employee">
        <p>
          {" "}
          I am <b>{this.props.name}</b> CodingLocker Employee,{" "}
        </p>
        <p>
          <b>{this.props.exp}</b> years of experience.{" "}
        </p>
        {/* <input type="text" onChange={this.props.mychange}
                value ={this.props.name}></input> */}
        <button onClick={this.props.myclick}> Delete Me!</button>
      </div>
    );
  }
}
